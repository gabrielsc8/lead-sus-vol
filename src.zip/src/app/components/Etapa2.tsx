"use client";

import { motion } from "framer-motion";
import { useState } from "react";

interface FormData {
  nome: string;
  whatsapp: string;
  sexo: string;
  email: string;
  voluntario: boolean;
  camiseta: string;
  membroDesde: string;
  voluntarioDesde: string;
  ministerio: string[]; // array de ministérios
  batizado: boolean;
  batizadoDesde: string;
}

interface Etapa2Props {
  form: FormData;
  handleChange: (e: React.ChangeEvent<any>) => void;
  onBack: () => void;
  onSubmit: () => void;
}

const ministeriosDisponiveis = [
  "Worship", "Integração", "V.I.P", "Kids", "Creative", "Parking", "Teens", "RdkBrave",
  "Lounge", "Connect", "Produção", "Cerimonial", "Campus Online", "Casais", "Clínica Da Alma",
  "Baby", "Coral", "Eventos", "Store"
];

export function Etapa2({ form, handleChange, onBack, onSubmit }: Etapa2Props) {
  const [loading, setLoading] = useState(false);

  const isValid = form.membroDesde &&
    (
      form.voluntario
        ? form.voluntarioDesde && form.ministerio.length > 0 && form.batizadoDesde
        : (!form.batizado || (form.batizado && form.batizadoDesde))
    );

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value === "true";
    handleChange({
      target: {
        name: "batizado",
        value,
      },
    } as React.ChangeEvent<any>);
  };

  const toggleMinisterio = (value: string) => {
    const alreadySelected = form.ministerio.includes(value);
    const updated = alreadySelected
      ? form.ministerio.filter((m) => m !== value)
      : [...form.ministerio, value];

    handleChange({
      target: {
        name: "ministerio",
        value: updated,
      },
    } as React.ChangeEvent<any>);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <p className="text-2sm text-gray-400 mb-2">2 →</p>
      <h2 className="text-xl font-regular mb-6 text-gray-800">
        Agora queremos saber um pouco da sua caminhada com Deus.
      </h2>

      <label className="block text-xl font-light text-gray-700">Membro desde *</label>
      <input
        type="date"
        min="2010-04-01"
        name="membroDesde"
        value={form.membroDesde}
        onChange={handleChange}
        className="mb-10 font-light text-xl w-full border-b bg-transparent text-gray-700 focus:outline-none focus:border-purple-700 focus:border-b-2 py-2"
        required
      />

      {form.voluntario ? (
        <>
          <label className="block text-xl font-light text-gray-700">Voluntário desde *</label>
          <input
            type="date"
            min="2010-04-01"
            name="voluntarioDesde"
            value={form.voluntarioDesde}
            onChange={handleChange}
            className="mb-10 font-light text-xl w-full border-b bg-transparent text-gray-700 focus:outline-none focus:border-purple-700 focus:border-b-2 py-2"
            required
          />

          <label className="block text-xl font-light text-gray-700 mt-4">
            Tamanho da camiseta *
          </label>
          <select
            name="camiseta"
            value={form.camiseta}
            onChange={handleChange}
            className="mb-10 w-full text-xl font-light border-b bg-transparent text-gray-700 focus:outline-none focus:border-purple-700 focus:border-b-2 py-2"
            required
          >
            <option value="">Selecione</option>
            <option value="PP">PP</option>
            <option value="P">P</option>
            <option value="M">M</option>
            <option value="G">G</option>
            <option value="GG">GG</option>
          </select>

          <label className="block text-xl font-light text-gray-700">
            Ministérios que serve *
          </label>
          <div className="grid grid-cols-2 gap-2 mb-10">
            {ministeriosDisponiveis.map((min) => (
              <label key={min} className="flex items-center gap-2 text-gray-700 cursor-pointer text-sm">
                <input
                  type="checkbox"
                  checked={form.ministerio.includes(min)}
                  onChange={() => toggleMinisterio(min)}
                />
                {min}
              </label>
            ))}
          </div>

          <label className="block text-xl font-light text-gray-700">Batizado desde *</label>
          <input
            type="date"
            min="2010-04-01"
            name="batizadoDesde"
            value={form.batizadoDesde}
            onChange={handleChange}
            className="mb-10 font-light text-xl w-full border-b bg-transparent text-gray-700 focus:outline-none focus:border-purple-700 focus:border-b-2 py-2"
            required
          />
        </>
      ) : (
        <>
          <label className="block text-xl font-light text-gray-700 mb-2">É batizado? *</label>
          <div className="flex gap-6 mb-10 text-gray-700 text-xl">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="batizado"
                value="true"
                checked={form.batizado === true}
                onChange={handleRadioChange}
              />
              Sim
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="batizado"
                value="false"
                checked={form.batizado === false}
                onChange={handleRadioChange}
              />
              Não
            </label>
          </div>

          {form.batizado && (
            <>
              <label className="block text-xl font-light text-gray-700">Batizado desde *</label>
              <input
                type="date"
                min="2010-04-01"
                name="batizadoDesde"
                value={form.batizadoDesde}
                onChange={handleChange}
                className="mb-10 font-light text-xl w-full border-b bg-transparent text-gray-700 focus:outline-none focus:border-purple-700 focus:border-b-2 py-2"
                required
              />
            </>
          )}
        </>
      )}

      <div className="flex justify-between mt-6">
        <button
          onClick={onBack}
          className="bg-gray-800 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md"
        >
          Voltar
        </button>

        <button
          onClick={async () => {
            if (loading || !isValid) return;
            setLoading(true);
            await onSubmit();
            setLoading(false);
          }}
          disabled={!isValid || loading}
          className={`w-1/2 font-semibold rounded-2xl py-3 px-5 transition ${!isValid || loading
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-gray-800 hover:bg-blue-700 text-white'
            }`}
        >
          {loading ? 'Enviando...' : 'Enviar'}
        </button>
      </div>
    </motion.div>
  );
}
