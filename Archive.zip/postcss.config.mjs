// postcss.config.mjs
export default {
  plugins: {
    // usa a string de chave conforme v4 exige:
    "@tailwindcss/postcss": {},
    // autoprefixer normal
    autoprefixer: {},
  },
};
